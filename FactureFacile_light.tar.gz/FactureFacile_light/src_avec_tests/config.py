# infos OpenAI (post-traitement)
OPENAI_API_KEY= 'sk-proj-uFZGeCnZwy57qto7TCGRT3BlbkFJev9bIfHazPmwVdNa88Et'

# infos DeepL (traduction)
DEEPL_API_KEY1 = 'bae55054-ab18-4a19-9773-b629ffe84e5e:fx'
DEEPL_API_KEY2 = '4ada3986-ed94-4f35-90f0-8767f268f64a:fx'

# infos API conversion
RAPID_API='bf14f36e15msh34de1f4d075f571p1fbb59jsndb8e58302711'

# infos MYSQL
HOST_MYSQL='projet-trad.mysql.database.azure.com'
USER_MYSQL='headofappli'
PASSWORD_MYSQL='aPp*lxujD_ic@ti0n'
DB_MYSQL='factures'

