#!/bin/bash

# mettre à jour les dépôts et installer Python3-pip, Tesseract OCR et Tkinter
sudo apt-get update
sudo apt-get install -y python3-pip tesseract-ocr tesseract-ocr-fra python3-tk

# installer les dépendances Python
pip install facturefacile-0.1.2-py3-none-any.whl

echo "Installation terminée avec succès."
